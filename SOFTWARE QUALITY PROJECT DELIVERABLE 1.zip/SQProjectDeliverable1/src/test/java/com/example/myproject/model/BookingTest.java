package com.example.myproject.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BookingTest {

    @Test
    public void CalculateTotalPriceTest1() {
        // Create a sample flight and user
        Flight flight = new Flight("New", null, null);
        User user = new User("Billy Bob", "bb@example.com");

        // Create a booking with the flight and user
        Booking booking = new Booking(flight, user, 1);

        // Test calculation of total price
        assertEquals(100.0, booking.calculateTotalPrice(), 0.01);
    }

    @Test
    public void CalculateTotalPriceTest2() {
        // Create a sample flight and user
        Flight flight = new Flight("ABC","ZEF", null, null);
        User user = new User("John Doe", "johndoe@example.com");

        // Create a booking with the flight and user
        Booking booking = new Booking(flight, user, 2);

        // Test calculation of total price
        assertEquals(200.0, booking.calculateTotalPrice(), 0.01);
    }
}
