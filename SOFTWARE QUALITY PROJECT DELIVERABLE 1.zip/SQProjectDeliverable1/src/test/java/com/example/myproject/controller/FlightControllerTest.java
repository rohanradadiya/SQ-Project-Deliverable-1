package com.example.myproject.controller;

import com.example.myproject.model.Flight;
import com.example.myproject.service.FlightService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class FlightControllerTest {

    @Mock
    private FlightService flightService;

    @InjectMocks
    private FlightController flightController;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllFlights() {
        // Prepare test data
        List<Flight> flights = Collections.singletonList(new Flight("ABC", "XYZ", null, null));

        // Mock service method
        when(flightService.getAllFlights()).thenReturn(flights);

        // Call controller method
        ResponseEntity<List<Flight>> response = flightController.getAllFlights();

        // Verify response
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(flights, response.getBody());
    }
}
