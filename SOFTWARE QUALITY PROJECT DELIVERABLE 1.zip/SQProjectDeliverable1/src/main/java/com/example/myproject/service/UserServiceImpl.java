package com.example.myproject.service;

public class UserServiceImpl implements UserService {
}
