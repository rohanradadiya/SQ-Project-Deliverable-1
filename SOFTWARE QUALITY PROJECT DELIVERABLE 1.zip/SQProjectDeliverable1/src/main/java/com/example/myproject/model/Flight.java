package com.example.myproject.model;

import java.time.LocalDateTime;

public class Flight {
    private String origin;
    private String destination;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;

    public int calculateFlightDuration() {
    }

    // Constructor, getters, and setters
}
