package com.example.myproject.model;

public class User {
    private String username;
    private String email;

    public String getUsername() {
    }

    public void getEmail() {
    }

    // Constructor, getters, and setters
}
