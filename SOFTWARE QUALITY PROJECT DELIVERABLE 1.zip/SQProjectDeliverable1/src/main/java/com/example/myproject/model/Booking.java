package com.example.myproject.model;

public class Booking {
    private Flight flight;
    private User user;
    private int numberOfPassengers;

    // Constructor, getters, and setters
}
